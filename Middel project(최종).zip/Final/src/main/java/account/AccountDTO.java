package account;

public class AccountDTO {
   
   private String id;
   private String deptn;
   private String name;
   private String pass;
   private String grade;
   private String pnum;
   private String ad;
   
   
public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String getDeptn() {
	return deptn;
}
public void setDeptn(String deptn) {
	this.deptn = deptn;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getPass() {
	return pass;
}
public void setPass(String pass) {
	this.pass = pass;
}
public String getGrade() {
	return grade;
}
public void setGrade(String grade) {
	this.grade = grade;
}
public String getPnum() {
	return pnum;
}
public void setPnum(String pnum) {
	this.pnum = pnum;
}
public String getAd() {
	return ad;
}
public void setAd(String ad) {
	this.ad = ad;
}
   
   

   
   

  
   

}